﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void TxtDataEntradaEmpresa_Click(object sender, EventArgs e)
        {

        }

        private void FrmHorista_Load(object sender, EventArgs e)
        {

        }

        private void TxtSalarioMensalista_Click(object sender, EventArgs e)
        {

        }

        private void TxtNome_Click(object sender, EventArgs e)
        {

        }

        private void TxtMatricula_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            
            objHorista.Matricula = Convert.ToInt32(txtMatricula1.Text);
            objHorista.NomeEmpregado = txtNome1.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtDataEntrada1.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtHora1.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtQtde1.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas1.Text);
            if (rbtnSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';



            MessageBox.Show("Matrícula: " + objHorista.Matricula + "\n" + "Nome: "
            + objHorista.NomeEmpregado + "\n" + "Data Entrada: " +
            objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" +
            "Salário Bruto: " + objHorista.SalarioBruto().ToString("N2") +
            "\n" + "Tempo Empresa (dias): " + objHorista.TempoTrabalho() +
            '\n' + objHorista.VerificaHome());
        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
