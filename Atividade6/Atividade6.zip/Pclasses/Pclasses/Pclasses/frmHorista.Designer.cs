﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.btnInstanciarH = new System.Windows.Forms.Button();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtSalarioMensalista = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.Label();
            this.txtDataEntrada1 = new System.Windows.Forms.TextBox();
            this.txtNome1 = new System.Windows.Forms.TextBox();
            this.txtHora1 = new System.Windows.Forms.TextBox();
            this.txtMatricula1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtQtde1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFaltas1 = new System.Windows.Forms.TextBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.gbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxHomeOffice
            // 
            this.gbxHomeOffice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbxHomeOffice.Controls.Add(this.radioButton2);
            this.gbxHomeOffice.Controls.Add(this.rbtnSim);
            this.gbxHomeOffice.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxHomeOffice.Location = new System.Drawing.Point(508, 55);
            this.gbxHomeOffice.Name = "gbxHomeOffice";
            this.gbxHomeOffice.Size = new System.Drawing.Size(235, 97);
            this.gbxHomeOffice.TabIndex = 31;
            this.gbxHomeOffice.TabStop = false;
            this.gbxHomeOffice.Text = "Trabalha em Home Office?";
            // 
            // btnInstanciarH
            // 
            this.btnInstanciarH.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstanciarH.Location = new System.Drawing.Point(209, 363);
            this.btnInstanciarH.Name = "btnInstanciarH";
            this.btnInstanciarH.Size = new System.Drawing.Size(297, 47);
            this.btnInstanciarH.TabIndex = 29;
            this.btnInstanciarH.Text = "Instanciar Horista";
            this.btnInstanciarH.UseVisualStyleBackColor = true;
            this.btnInstanciarH.Click += new System.EventHandler(this.Button1_Click);
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.AutoSize = true;
            this.txtDataEntradaEmpresa.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(2, 203);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(253, 22);
            this.txtDataEntradaEmpresa.TabIndex = 28;
            this.txtDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtSalarioMensalista
            // 
            this.txtSalarioMensalista.AutoSize = true;
            this.txtSalarioMensalista.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioMensalista.Location = new System.Drawing.Point(13, 152);
            this.txtSalarioMensalista.Name = "txtSalarioMensalista";
            this.txtSalarioMensalista.Size = new System.Drawing.Size(113, 22);
            this.txtSalarioMensalista.TabIndex = 27;
            this.txtSalarioMensalista.Text = "Salário Hora";
            // 
            // txtNome
            // 
            this.txtNome.AutoSize = true;
            this.txtNome.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(13, 101);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(61, 22);
            this.txtNome.TabIndex = 26;
            this.txtNome.Text = "Nome";
            // 
            // txtMatricula
            // 
            this.txtMatricula.AutoSize = true;
            this.txtMatricula.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(13, 50);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(86, 22);
            this.txtMatricula.TabIndex = 25;
            this.txtMatricula.Text = "Matrícula";
            // 
            // txtDataEntrada1
            // 
            this.txtDataEntrada1.Location = new System.Drawing.Point(276, 207);
            this.txtDataEntrada1.Name = "txtDataEntrada1";
            this.txtDataEntrada1.Size = new System.Drawing.Size(180, 20);
            this.txtDataEntrada1.TabIndex = 24;
            this.txtDataEntrada1.TextChanged += new System.EventHandler(this.TextBox4_TextChanged);
            // 
            // txtNome1
            // 
            this.txtNome1.Location = new System.Drawing.Point(276, 105);
            this.txtNome1.Name = "txtNome1";
            this.txtNome1.Size = new System.Drawing.Size(180, 20);
            this.txtNome1.TabIndex = 22;
            // 
            // txtHora1
            // 
            this.txtHora1.Location = new System.Drawing.Point(276, 156);
            this.txtHora1.Name = "txtHora1";
            this.txtHora1.Size = new System.Drawing.Size(180, 20);
            this.txtHora1.TabIndex = 23;
            // 
            // txtMatricula1
            // 
            this.txtMatricula1.Location = new System.Drawing.Point(276, 54);
            this.txtMatricula1.Name = "txtMatricula1";
            this.txtMatricula1.Size = new System.Drawing.Size(180, 20);
            this.txtMatricula1.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 254);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(162, 22);
            this.label1.TabIndex = 33;
            this.label1.Text = "Horas trabalhadas";
            // 
            // txtQtde1
            // 
            this.txtQtde1.Location = new System.Drawing.Point(276, 258);
            this.txtQtde1.Name = "txtQtde1";
            this.txtQtde1.Size = new System.Drawing.Size(180, 20);
            this.txtQtde1.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 305);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 22);
            this.label2.TabIndex = 35;
            this.label2.Text = "Dias de falta";
            // 
            // txtFaltas1
            // 
            this.txtFaltas1.Location = new System.Drawing.Point(276, 309);
            this.txtFaltas1.Name = "txtFaltas1";
            this.txtFaltas1.Size = new System.Drawing.Size(180, 20);
            this.txtFaltas1.TabIndex = 34;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(6, 55);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(61, 26);
            this.rbtnSim.TabIndex = 2;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(147, 55);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(62, 26);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Não";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 441);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFaltas1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtQtde1);
            this.Controls.Add(this.gbxHomeOffice);
            this.Controls.Add(this.btnInstanciarH);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtSalarioMensalista);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtDataEntrada1);
            this.Controls.Add(this.txtNome1);
            this.Controls.Add(this.txtHora1);
            this.Controls.Add(this.txtMatricula1);
            this.Name = "frmHorista";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.FrmHorista_Load);
            this.gbxHomeOffice.ResumeLayout(false);
            this.gbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxHomeOffice;
        private System.Windows.Forms.Button btnInstanciarH;
        private System.Windows.Forms.Label txtDataEntradaEmpresa;
        private System.Windows.Forms.Label txtSalarioMensalista;
        private System.Windows.Forms.Label txtNome;
        private System.Windows.Forms.Label txtMatricula;
        private System.Windows.Forms.TextBox txtDataEntrada1;
        private System.Windows.Forms.TextBox txtNome1;
        private System.Windows.Forms.TextBox txtHora1;
        private System.Windows.Forms.TextBox txtMatricula1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtQtde1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFaltas1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton rbtnSim;
    }
}