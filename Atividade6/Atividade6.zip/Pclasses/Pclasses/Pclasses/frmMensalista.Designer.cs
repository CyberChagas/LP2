﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.btnMensalista2 = new System.Windows.Forms.Button();
            this.BtnMensalista = new System.Windows.Forms.Button();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtSalarioMensalista = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.Label();
            this.txtDataEntradaEmpresa2 = new System.Windows.Forms.TextBox();
            this.txtNome2 = new System.Windows.Forms.TextBox();
            this.txtSalarioMensalista2 = new System.Windows.Forms.TextBox();
            this.txtMatricula2 = new System.Windows.Forms.TextBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.gbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxHomeOffice
            // 
            this.gbxHomeOffice.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbxHomeOffice.Controls.Add(this.rbtnNao);
            this.gbxHomeOffice.Controls.Add(this.rbtnSim);
            this.gbxHomeOffice.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxHomeOffice.Location = new System.Drawing.Point(553, 55);
            this.gbxHomeOffice.Name = "gbxHomeOffice";
            this.gbxHomeOffice.Size = new System.Drawing.Size(235, 97);
            this.gbxHomeOffice.TabIndex = 20;
            this.gbxHomeOffice.TabStop = false;
            this.gbxHomeOffice.Text = "Trabalha em Home Office?";
            // 
            // btnMensalista2
            // 
            this.btnMensalista2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMensalista2.Location = new System.Drawing.Point(412, 349);
            this.btnMensalista2.Name = "btnMensalista2";
            this.btnMensalista2.Size = new System.Drawing.Size(297, 47);
            this.btnMensalista2.TabIndex = 19;
            this.btnMensalista2.Text = "Instanciar Mensalista passando parâmetros";
            this.btnMensalista2.UseVisualStyleBackColor = true;
            this.btnMensalista2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // BtnMensalista
            // 
            this.BtnMensalista.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMensalista.Location = new System.Drawing.Point(85, 349);
            this.BtnMensalista.Name = "BtnMensalista";
            this.BtnMensalista.Size = new System.Drawing.Size(297, 47);
            this.BtnMensalista.TabIndex = 18;
            this.BtnMensalista.Text = "Instanciar Mensalista";
            this.BtnMensalista.UseVisualStyleBackColor = true;
            this.BtnMensalista.Click += new System.EventHandler(this.Button1_Click);
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.AutoSize = true;
            this.txtDataEntradaEmpresa.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(58, 267);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(253, 22);
            this.txtDataEntradaEmpresa.TabIndex = 17;
            this.txtDataEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // txtSalarioMensalista
            // 
            this.txtSalarioMensalista.AutoSize = true;
            this.txtSalarioMensalista.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioMensalista.Location = new System.Drawing.Point(58, 196);
            this.txtSalarioMensalista.Name = "txtSalarioMensalista";
            this.txtSalarioMensalista.Size = new System.Drawing.Size(133, 22);
            this.txtSalarioMensalista.TabIndex = 16;
            this.txtSalarioMensalista.Text = "Salário Mensal";
            // 
            // txtNome
            // 
            this.txtNome.AutoSize = true;
            this.txtNome.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(58, 120);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(61, 22);
            this.txtNome.TabIndex = 15;
            this.txtNome.Text = "Nome";
            // 
            // txtMatricula
            // 
            this.txtMatricula.AutoSize = true;
            this.txtMatricula.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(58, 64);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(86, 22);
            this.txtMatricula.TabIndex = 14;
            this.txtMatricula.Text = "Matrícula";
            // 
            // txtDataEntradaEmpresa2
            // 
            this.txtDataEntradaEmpresa2.Location = new System.Drawing.Point(316, 271);
            this.txtDataEntradaEmpresa2.Name = "txtDataEntradaEmpresa2";
            this.txtDataEntradaEmpresa2.Size = new System.Drawing.Size(180, 20);
            this.txtDataEntradaEmpresa2.TabIndex = 13;
            this.txtDataEntradaEmpresa2.TextChanged += new System.EventHandler(this.TextBox4_TextChanged);
            // 
            // txtNome2
            // 
            this.txtNome2.Location = new System.Drawing.Point(316, 120);
            this.txtNome2.Name = "txtNome2";
            this.txtNome2.Size = new System.Drawing.Size(180, 20);
            this.txtNome2.TabIndex = 11;
            this.txtNome2.TextChanged += new System.EventHandler(this.TextBox3_TextChanged);
            // 
            // txtSalarioMensalista2
            // 
            this.txtSalarioMensalista2.Location = new System.Drawing.Point(316, 196);
            this.txtSalarioMensalista2.Name = "txtSalarioMensalista2";
            this.txtSalarioMensalista2.Size = new System.Drawing.Size(180, 20);
            this.txtSalarioMensalista2.TabIndex = 12;
            // 
            // txtMatricula2
            // 
            this.txtMatricula2.Location = new System.Drawing.Point(316, 64);
            this.txtMatricula2.Name = "txtMatricula2";
            this.txtMatricula2.Size = new System.Drawing.Size(180, 20);
            this.txtMatricula2.TabIndex = 10;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(154, 54);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(62, 26);
            this.rbtnNao.TabIndex = 22;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(13, 54);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(61, 26);
            this.rbtnSim.TabIndex = 21;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.gbxHomeOffice);
            this.Controls.Add(this.btnMensalista2);
            this.Controls.Add(this.BtnMensalista);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtSalarioMensalista);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtDataEntradaEmpresa2);
            this.Controls.Add(this.txtNome2);
            this.Controls.Add(this.txtSalarioMensalista2);
            this.Controls.Add(this.txtMatricula2);
            this.Name = "frmMensalista";
            this.Text = "Form2";
            this.gbxHomeOffice.ResumeLayout(false);
            this.gbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxHomeOffice;
        private System.Windows.Forms.Button btnMensalista2;
        private System.Windows.Forms.Button BtnMensalista;
        private System.Windows.Forms.Label txtDataEntradaEmpresa;
        private System.Windows.Forms.Label txtSalarioMensalista;
        private System.Windows.Forms.Label txtNome;
        private System.Windows.Forms.Label txtMatricula;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa2;
        private System.Windows.Forms.TextBox txtNome2;
        private System.Windows.Forms.TextBox txtSalarioMensalista2;
        private System.Windows.Forms.TextBox txtMatricula2;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
    }
}