﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++) {
            Total += Alunos[I].Length; }
            MessageBox.Show(Total.ToString());
            MessageBox.Show("Versão 2: ");
            Total = 0;
            I = 0;

            for (I = 0; I < N; I++){
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            List<string> Alunos = new List<string> { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            Alunos.Remove("Otávio");
            Int32 I, Total = 0;
            Int32 N = Alunos.Count;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            static string ShowInputBox(string prompt)
            {
                string nome = ShowInputBox("Digite seu nome:");
                Form promptForm = new Form()
                {
                    Width = 300,
                    Height = 150,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = "Input Box",
                    StartPosition = FormStartPosition.CenterScreen
                };
                Label promptLabel = new Label() { Left = 50, Top = 20, Text = prompt };
                TextBox textBox = new TextBox() { Left = 50, Top = 50, Width = 200 };
                Button confirmationButton = new Button() { Text = "OK", Left = 150, Width = 80, Top = 70 };
                confirmationButton.Click += (sender, e) => { promptForm.Close(); };
                promptForm.Controls.Add(textBox);
                promptForm.Controls.Add(promptLabel);
                promptForm.Controls.Add(confirmationButton);
                promptForm.ShowDialog();
                return textBox.Text;
            }
        }
        /*List<int> numeros = new List<int>();
        for (int i = 0; i < 20; i++)
        {
            MessageBox.Show($"Digite o número { i + 1}: ");
            int numero = int.Parse(Console.ReadLine());
            numeros.Add(numero);
        }*/
    }
    }
}
