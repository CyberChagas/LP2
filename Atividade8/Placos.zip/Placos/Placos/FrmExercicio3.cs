﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Placos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string textoS = "";
            string textoEntrada = "";

            for (int i = 0; i < txtTexto.Text.Length; i++)
            {
                if (txtTexto.Text[i] != ' ')
                {
                    textoEntrada += Char.ToLower(txtTexto.Text[i]);
                }
            }

            char[] auxiliar = textoEntrada.ToCharArray();

            Array.Reverse(auxiliar);

            foreach (char caracter in auxiliar)
            {
                textoS += caracter;
            }

            if (textoS == textoEntrada)
            {
                MessageBox.Show($"texto é palíndromo: {textoS}");
            }
            else
            {
                MessageBox.Show($"texto não é palíndromo: {textoS}");
            }
        }
    }
}
